package iset.gestion.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCatMvcApplication  {
	public static void main(String[] args) {
		SpringApplication.run(SpringCatMvcApplication.class, args);
	}
}
